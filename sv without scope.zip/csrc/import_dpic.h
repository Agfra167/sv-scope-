
 extern int func_dpi(/* INPUT */int n1, /* INOUT */int *n2, /* OUTPUT */int *n3);

 extern int func_dpi(/* INPUT */int n1, /* INOUT */int *n2, /* OUTPUT */int *n3);
